// Chatbot functionality
let chatHistory = [];

function toggleChat() {
    const chatbotWindow = document.getElementById('chatbotWindow');
    chatbotWindow.style.display = chatbotWindow.style.display === 'none' ? 'flex' : 'none';
}

async function sendMessage() {
    const userInput = document.getElementById('userInput');
    const message = userInput.value.trim();
    const messagesContainer = document.getElementById('chatbotMessages');
    
    if (message) {
        // Clear input immediately after getting the message
        userInput.value = '';
        
        // Add user message
        const userMessageDiv = document.createElement('div');
        userMessageDiv.className = 'message user-message';
        userMessageDiv.textContent = message;
        messagesContainer.appendChild(userMessageDiv);
        
        // Add loading message
        const loadingDiv = document.createElement('div');
        loadingDiv.className = 'message bot-message loading';
        loadingDiv.textContent = "Thinking...";
        messagesContainer.appendChild(loadingDiv);
        
        try {
            // Get response from Gemini
            const response = await getGeminiResponse(message);
            
            // Remove loading message
            messagesContainer.removeChild(loadingDiv);
            
            // Add bot response with markdown rendering
            const botMessageDiv = document.createElement('div');
            botMessageDiv.className = 'message bot-message';
            botMessageDiv.innerHTML = marked.parse(response);
            messagesContainer.appendChild(botMessageDiv);
            
            // Update chat history
            chatHistory.push(
                { role: "user", parts: [{ text: message }] },
                { role: "model", parts: [{ text: response }] }
            );
        } catch (error) {
            // Remove loading message
            messagesContainer.removeChild(loadingDiv);
            
            // Show error message
            const errorDiv = document.createElement('div');
            errorDiv.className = 'message bot-message error';
            errorDiv.textContent = "Sorry, I encountered an error. Please try again.";
            messagesContainer.appendChild(errorDiv);
            console.error('Error:', error);
        }
        
        // Scroll to bottom
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
}

async function getGeminiResponse(message) {
    try {
        const response = await fetch(`${GEMINI_API_URL}?key=${GEMINI_API_KEY}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                contents: [{
                    parts: [{
                        text: `You are a helpful e-commerce assistant. Previous conversation: ${JSON.stringify(chatHistory)}. User's message: ${message}`
                    }]
                }],
                generationConfig: {
                    temperature: 0.7,
                    topK: 40,
                    topP: 0.95,
                    maxOutputTokens: 1024,
                },
                safetySettings: [
                    {
                        category: "HARM_CATEGORY_HARASSMENT",
                        threshold: "BLOCK_MEDIUM_AND_ABOVE"
                    },
                    {
                        category: "HARM_CATEGORY_HATE_SPEECH",
                        threshold: "BLOCK_MEDIUM_AND_ABOVE"
                    },
                    {
                        category: "HARM_CATEGORY_SEXUALLY_EXPLICIT",
                        threshold: "BLOCK_MEDIUM_AND_ABOVE"
                    },
                    {
                        category: "HARM_CATEGORY_DANGEROUS_CONTENT",
                        threshold: "BLOCK_MEDIUM_AND_ABOVE"
                    }
                ]
            })
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(`HTTP error! status: ${response.status}, message: ${JSON.stringify(errorData)}`);
        }

        const data = await response.json();
        return data.candidates[0].content.parts[0].text;
    } catch (error) {
        throw error;
    }
}

function handleKeyPress(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
} 