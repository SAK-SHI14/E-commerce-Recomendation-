// Gemini API Configuration
const GEMINI_API_KEY = 'AIzaSyCKtIh4_t4AJZFF-u07kONRYpbV0ZnOseI';
const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent'; 